package com.onlineadvertisement.dto;


import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class UserDTOTest {

	UserDTO userDTO;
	
	@BeforeEach
	public void setUp() {
		userDTO=new UserDTO();
		userDTO.setName("abhi");
		userDTO.setAddress("bangalore");
		userDTO.setContactNo("9826323");
		userDTO.setEmail("abhi@gmail.com");
		userDTO.setUserName("abhi");
		userDTO.setPassword("1234");
	}

	@Test
	public void testGet() {
		assertEquals("abhi",userDTO.getName());
		assertEquals("bangalore",userDTO.getAddress());
		assertEquals("9826323",userDTO.getContactNo());
		assertEquals("abhi@gmail.com",userDTO.getEmail());
		assertEquals("abhi",userDTO.getUserName());
		assertEquals("1234",userDTO.getPassword());
	}



}
