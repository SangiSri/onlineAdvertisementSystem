package com.onlineadvertisement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineAdvertisementSystemApplicationTests {

	
	
	@Test
	void contextLoads() {
	}

}
