package com.onlineadvertisement.serviceimpl;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.onlineadvertisement.dto.AdvertisementDTO;
import com.onlineadvertisement.dto.CategoryDTO;
import com.onlineadvertisement.dto.CustomerDTO;
import com.onlineadvertisement.dto.MessageDTO;
import com.onlineadvertisement.entity.Advertisement;
import com.onlineadvertisement.entity.Category;
import com.onlineadvertisement.entity.Customer;
import com.onlineadvertisement.entity.Message;
import com.onlineadvertisement.entity.User;
import com.onlineadvertisement.exception.CustomerAlreadyExistException;
import com.onlineadvertisement.repository.AdvertisementRepository;
import com.onlineadvertisement.repository.CustomerRepository;
import com.onlineadvertisement.repository.UserRepository;
import com.onlineadvertisement.utils.Converter;

@SpringBootTest
class UserServiceImplTest {
	@InjectMocks
	 UserServiceImpl userService;
	
	@Mock
	UserRepository userRepo;
	
	@Mock
	 CustomerRepository customerRepo;
	
	@Mock
	 AdvertisementRepository advertisementRepo;
	
	static Customer customer;
	static CustomerDTO customerDTO;
	static Advertisement advertisement;
	static AdvertisementDTO advertisementDTO;
	static CategoryDTO categoryDTO;
	static Category category;
	static MessageDTO messageDTO;
	static Message message;
	@Mock
	Converter converter;
	
	@BeforeEach
	public void setUp() {
		customer=new Customer();
		customerDTO=new CustomerDTO();
		customerDTO.setName("jeevan");
		customerDTO.setAddress("mandya");
		customerDTO.setContactNo("9878356");
		customerDTO.setEmail("jeevan@gmail.com");
		customerDTO.setUserName("jeev");
		customerDTO.setPassword("1234");
		
		category=new Category();
		categoryDTO=new CategoryDTO();
		
		categoryDTO.setCategoryName("Electronics");
		categoryDTO.setCategoryDesc("Add electronics");
		
		advertisementDTO=new AdvertisementDTO();
		advertisement=new Advertisement();
		advertisementDTO.setAdvertiseTitle("mobile");
		advertisementDTO.setCategoryDTO(categoryDTO);
		advertisementDTO.setCustomerDTO(customerDTO);
		advertisementDTO.setDescription("buy it");
		advertisementDTO.setPrice(900);
		advertisementDTO.setStatus("Inprocess");
	}
	
	@Test
	public void testRegisterCustomer()throws  CustomerAlreadyExistException {
		Mockito.when(userRepo.existsByUserName("jeev")).thenReturn(false);
		Mockito.when(converter.convertToCustomerEntity(customerDTO)).thenReturn(customer);
		Mockito.when(customerRepo.save(customer)).thenReturn(customer);
		assertEquals("register Successfull",userService.registerCustomer(customerDTO));
	}
	
	@Test
	public void testLogin(){
		User user = new User();
		String userName=customer.getUserName();
		String password =customer.getPassword();
		Mockito.when(userRepo.findByUserNameAndPassword(userName, password)).thenReturn(user);
		assertEquals(user,userService.loginCustomer(userName, password));
		
	}	

	@Test
	public void testPostNewAdvertise() {
		Mockito.when(converter.convertToAdvertisementEntity(advertisementDTO)).thenReturn(advertisement);
		Mockito.when(advertisementRepo.save(advertisement)).thenReturn(advertisement);
		assertEquals(advertisement,userService. postNewAdvertise(advertisementDTO));
	}

}
	
