package com.onlineadvertisement.serviceimpl;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.onlineadvertisement.dto.AdminDTO;
import com.onlineadvertisement.dto.CategoryDTO;
import com.onlineadvertisement.entity.Admin;
import com.onlineadvertisement.entity.Category;
import com.onlineadvertisement.entity.User;
import com.onlineadvertisement.repository.AdminRepository;
import com.onlineadvertisement.repository.AdvertisementRepository;
import com.onlineadvertisement.repository.CategoryRepository;
import com.onlineadvertisement.repository.UserRepository;
import com.onlineadvertisement.utils.Converter;

class AdministratorServiceImplTest {

	@InjectMocks
	 AdministratorServiceImpl userService;
	
	@Mock
	UserRepository userRepo;
	
	@Mock
	 AdminRepository adminRepo;
	
	@Mock
	 AdvertisementRepository advertisementRepo;
	
	@Mock
	CategoryRepository categoryRepo;
	
	static CategoryDTO categoryDTO;
	static Category category;
	
	static Admin admin;
	static AdminDTO adminDTO;
	@Mock
	Converter converter;
	
	@BeforeEach
	public void setUp() {
		admin=new Admin();
		adminDTO=new AdminDTO();
		adminDTO.setName("jeevan");
		adminDTO.setAddress("mandya");
		adminDTO.setContactNo("9878356");
		adminDTO.setEmail("jeevan@gmail.com");
		adminDTO.setUserName("jeev");
		adminDTO.setPassword("1234");
		adminDTO.setDesignation("IT Service");
		
		category = new Category();
		categoryDTO=new CategoryDTO();
		
		categoryDTO.setCategoryName("Electronics");
		categoryDTO.setCategoryDesc("Add electronics");
		
		
	}
	
	@Test
	void testRegisterAdmin() {
		Mockito.when(userRepo.existsByUserName("jeev")).thenReturn(false);
		Mockito.when(converter.convertToAdminEntity(adminDTO)).thenReturn(admin);
		Mockito.when(adminRepo.save(admin)).thenReturn(admin);
		assertEquals("register Successfull",userService.registerAdmin(adminDTO));
	}

	@Test
	void testLoginAdmin() {
		User user = new User();
		String userName=admin.getUserName();
		String password =admin.getPassword();
		Mockito.when(userRepo.findByUserNameAndPassword(userName, password)).thenReturn(user);
		assertEquals(user,userService.loginAdmin(userName, password));
	}

	@Test
	void testAddCategory() {
		Mockito.when(converter.convertToCategoryEntity(categoryDTO)).thenReturn(category);
		Mockito.when(categoryRepo.save(category)).thenReturn(category);
		assertEquals("register Successfull",userService.registerAdmin(adminDTO));
	}

	
}
