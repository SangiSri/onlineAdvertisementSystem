package com.onlineadvertisement.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="users")
@Inheritance(strategy=InheritanceType.JOINED)
public class User {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int usrId;
	
	@NotNull
	private String name;
	
	@NotNull
	private String address;
	
	@NotNull
	@Email
	private String email;
	
	@NotNull
	private String contactNo;
	
	@NotNull
	private String userName;
	
	@NotNull
	private String password;

	public User() {
		super();
	}

	public User(int usrId, @NotNull String name, @NotNull String address, @NotNull String email,
			@NotNull String contactNo, @NotNull String userName, @NotNull String password) {
		super();
		this.usrId = usrId;
		this.name = name;
		this.address = address;
		this.email = email;
		this.contactNo = contactNo;
		this.userName = userName;
		this.password = password;
	}

	public int getUsrId() {
		return usrId;
	}

	public void setUsrId(int usrId) {
		this.usrId = usrId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public  String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "User [usrId=" + usrId + ", Name=" + name + ", address=" + address + ", Email=" + email + ", contactNo="
				+ contactNo + ", userName=" + userName + ", password=" + password + "]";
	}
	
	
	
}
