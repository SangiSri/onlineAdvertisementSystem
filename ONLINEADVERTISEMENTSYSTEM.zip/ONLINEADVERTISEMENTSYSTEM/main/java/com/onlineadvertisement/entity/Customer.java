package com.onlineadvertisement.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;

@Entity
public class Customer extends User {

	@OneToMany(cascade=CascadeType.ALL,mappedBy="customer")
	private List<Advertisement> advertisements=new ArrayList<>();
	
//	@OneToMany
//	@JoinColumn(name="msgId")
//	private List<Message> messages=new ArrayList<>();

	public Customer() {
		super();
	}

	
	public Customer(List<Advertisement> advertisements) {
		super();
		this.advertisements = advertisements;
//		this.messages = messages;
	}


	public List<Advertisement> getAdvertisements() {
		return advertisements;
	}

	public void setAdvertisements(List<Advertisement> advertisements) {
		this.advertisements = advertisements;
	}
	
	

//	public List<Message> getMessages() {
//		return messages;
//	}
//
//
//	public void setMessages(List<Message> messages) {
//		this.messages = messages;
//	}


	@Override
	public String toString() {
		return "Customer [advertisements=" + advertisements +  "]";
	}


	
	
}
