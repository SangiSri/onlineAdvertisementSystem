package com.onlineadvertisement.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

@Entity
public class Message {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int msgID;
	
	@OneToOne
	@JoinColumn(name="advertisementId")
	private Advertisement advertise;
	
	@NotNull
	private String senderUserName;
	
	@NotNull
	private String message;
	
//	@ManyToOne
//	@JsonIgnore
//	private Customer customer;

	public Message() {
		super();
	}

	

	public Message(int msgID, @NotNull String senderUserName, @NotNull String message) {
		super();
		this.msgID = msgID;
		this.advertise = advertise;
		this.senderUserName = senderUserName;
		this.message = message;
//		this.customer = customer;
	}



//	public Advertisement getAdvertise() {
//		return advertise;
//	}
//
//
//	public void setAdvertise(Advertisement advertise) {
//		this.advertise = advertise;
//	}



//	public Customer getCustomer() {
//		return customer;
//	}
//
//
//
//	public void setCustomer(Customer customer) {
//		this.customer = customer;
//	}



	public int getMsgID() {
		return msgID;
	}

	public void setMsgID(int msgID) {
		this.msgID = msgID;
	}

	
	public String getSenderUserName() {
		return senderUserName;
	}

	public void setSenderUserName(String senderUserName) {
		this.senderUserName = senderUserName;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}



	@Override
	public String toString() {
		return "Message [msgID=" + msgID + ", senderUserName=" + senderUserName
				+ ", message=" + message +  "]";
	}

	
	
	
	
}
