package com.onlineadvertisement.exception;

public class AdvertiseNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public AdvertiseNotFoundException(String message) {
		super(message);
	}

}
