package com.onlineadvertisement.dto;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class AdvertisementDTO {
	
	
	private int advertisementId;
	private String advertiseTitle;
	private CategoryDTO categoryDTO;
	private double price;
	private String description;
	private CustomerDTO customerDTO;
	private String status;
	private List<MessageDTO> messages=new ArrayList<>();

	public AdvertisementDTO() {
		super();
	}

	public AdvertisementDTO(int advertisementId, String advertiseTitle, CategoryDTO categoryDTO, double price,
			String description, CustomerDTO customerDTO, String status, List<MessageDTO> messages) {
		super();
		this.advertisementId = advertisementId;
		this.advertiseTitle = advertiseTitle;
		this.categoryDTO = categoryDTO;
		this.price = price;
		this.description = description;
		this.customerDTO = customerDTO;
		this.status = status;
		this.messages = messages;
	}


	public List<MessageDTO> getMessages() {
		return messages;
	}

	public void setMessages(List<MessageDTO> messages) {
		this.messages = messages;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public CustomerDTO getCustomerDTO() {
		return customerDTO;
	}


	public void setCustomer(CustomerDTO customerDTO) {
		this.customerDTO = customerDTO;
	}


	public void setCategory(CategoryDTO categoryDTO) {
		this.categoryDTO = categoryDTO;
	}


	public int getAdvertisementId() {
		return advertisementId;
	}

	public void setAdvertisementId(int advertisementId) {
		this.advertisementId = advertisementId;
	}

	public String getAdvertiseTitle() {
		return advertiseTitle;
	}

	public void setAdvertiseTitle(String advertiseTitle) {
		this.advertiseTitle = advertiseTitle;
	}



	public CategoryDTO getCategoryDTO() {
		return categoryDTO;
	}


	public void setCategoryDTO(CategoryDTO categoryDTO) {
		this.categoryDTO = categoryDTO;
	}


	

	public void setCustomerDTO(CustomerDTO customerDTO) {
		this.customerDTO = customerDTO;
	}


	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}


	@Override
	public String toString() {
		return "AdvertisementDTO [advertisementId=" + advertisementId + ", advertiseTitle=" + advertiseTitle
				+ ", categoryDTO=" + categoryDTO + ", price=" + price + ", description=" + description
				+ ", customerDTO=" + customerDTO + ", status=" + status + ", messages=" + messages + "]";
	}



	

	
}

