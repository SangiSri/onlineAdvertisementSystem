package com.onlineadvertisement.dto;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class CustomerDTO extends UserDTO {

	private List<AdvertisementDTO> advertisements=new ArrayList<>();

	public CustomerDTO() {
		super();
	}

	public CustomerDTO(List<AdvertisementDTO> advertisements) {
		super();
		this.advertisements = advertisements;
	}

	public List<AdvertisementDTO> getAdvertisements() {
		return advertisements;
	}

	public void setAdvertisements(List<AdvertisementDTO> advertisements) {
		this.advertisements = advertisements;
	}

	@Override
	public String toString() {
		return "Customer [advertisements=" + advertisements + "]";
	}
	
	
}
