package com.onlineadvertisement.dto;

import org.springframework.stereotype.Component;

@Component
public class MessageDTO {

	
	private int msgID;
	private int advertisementId;
	private String senderUserName;
	private String message;

	public MessageDTO() {
		super();
	}

	public MessageDTO(int msgID, String senderUserName, String message) {
		super();
		this.msgID = msgID;
    	this.advertisementId = advertisementId;
		this.senderUserName = senderUserName;
		this.message = message;
	}

	public int getMsgID() {
		return msgID;
	}

	public void setMsgID(int msgID) {
		this.msgID = msgID;
	}

	
	public int getAdvertisementId() {
		return advertisementId;
	}

	public void setAdvertisementId(int advertisementId) {
		this.advertisementId = advertisementId;
	}

	public String getSenderUserName() {
		return senderUserName;
	}

	public void setSenderUserName(String senderUserName) {
		this.senderUserName = senderUserName;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "MessageDTO [msgID=" + msgID + ", advertisementId=" + advertisementId + ", senderUserName="
				+ senderUserName + ", message=" + message + "]";
	}

	
	
}
