package com.onlineadvertisement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineAdvertisementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineAdvertisementSystemApplication.class, args);
	}

}
