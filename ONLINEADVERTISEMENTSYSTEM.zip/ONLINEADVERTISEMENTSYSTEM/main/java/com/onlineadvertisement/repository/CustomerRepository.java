package com.onlineadvertisement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.onlineadvertisement.entity.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {

//	@Query("SELECT u FROM Customer u WHERE user_type='customer' AND u.userName=:userName AND u.password=:password")
//	public Customer findByUserNameAndPassword(@Param("userName") String userName,@Param("password")String password);
		public Customer findByUserName(String userName);
	
}
