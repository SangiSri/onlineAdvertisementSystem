package com.onlineadvertisement.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlineadvertisement.dto.AdvertisementDTO;
import com.onlineadvertisement.dto.CustomerDTO;
import com.onlineadvertisement.dto.MessageDTO;
import com.onlineadvertisement.entity.Advertisement;
import com.onlineadvertisement.entity.Customer;
import com.onlineadvertisement.entity.Message;
import com.onlineadvertisement.entity.User;
import com.onlineadvertisement.exception.AdvertiseNotFoundException;
import com.onlineadvertisement.exception.CustomerAlreadyExistException;
import com.onlineadvertisement.exception.CustomerNotFoundException;
import com.onlineadvertisement.repository.AdvertisementRepository;
import com.onlineadvertisement.repository.CustomerRepository;
import com.onlineadvertisement.repository.MessageRepository;
import com.onlineadvertisement.repository.UserRepository;
import com.onlineadvertisement.service.UserService;
import com.onlineadvertisement.utils.Converter;

@Service
public class UserServiceImpl implements UserService {

	
	private static final Integer usrId = null;
	private static final Integer advertisementId= null;
	
//	public UserServiceImpl(UserRepository userRepo) {
//		this.userRepo=userRepo;
//	}

	@Autowired
	private CustomerRepository customerRepo;
	
	@Autowired
    private AdvertisementRepository advertisementRepo;
	
	@Autowired
    private MessageRepository messageRepo;
	
	@Autowired
	private UserRepository userRepo;
    
	@Autowired
	private Converter converter;
	
	@Override
	public String registerCustomer(CustomerDTO customerDTO) {
		Customer customer=null;
		 if(this.userRepo.existsByUserName(customerDTO.getUserName())) {
		        throw new CustomerAlreadyExistException("User with given userName already exist");
		 }
		  customer=customerRepo.save(converter.convertToCustomerEntity(customerDTO));
		 System.out.println(customer);
		 if(customer!=null) {
		 return "register Successfull";
		 }
		 return "register not Successfull";
	}

	@Override
	public User loginCustomer(String userName, String password) {
		System.out.println(userName+" "+password);
		User user=userRepo.findByUserNameAndPassword(userName, password);
		
		if(user==null) { 
			throw new CustomerNotFoundException("No such Customer");
		}
		
		return user;
	}

	@Override
	public Customer editUserProfile(CustomerDTO customerDTO) {
	
		return customerRepo.save(converter.convertToCustomerEntity(customerDTO));
	
	}

	@Override
	public Advertisement postNewAdvertise(AdvertisementDTO advertiseDTO) {
		return advertisementRepo.save(converter.convertToAdvertisementEntity(advertiseDTO));
	}

	@Override
	public Advertisement editAdvertise(AdvertisementDTO advertiseDTO) {
		
		return advertisementRepo.save(converter.convertToAdvertisementEntity(advertiseDTO));
		
		
	}

	@Override
	public List<Advertisement> readAllAdvertises() {
		return advertisementRepo.findAll();
	}

	@Override
	public Advertisement readtheSpecificAdvertiseById(int advertisementId ){
		Optional<Advertisement> advertisement = advertisementRepo.findById(advertisementId);
		Advertisement advertise = null;
		if(advertisement.isPresent())
		{
		advertise = advertisement.get();
		}
		else {
		throw new AdvertiseNotFoundException("No such Advertisement");
		}
		return advertise;
	}

	@Override
	public Advertisement deleteAdvertise(int advertisementId){
		Optional<Advertisement> advertisement = advertisementRepo.findById(advertisementId);
		Advertisement advertise = null;
		if(advertisement.isPresent()) {
			advertisementRepo.deleteById(advertisementId);
			advertise = advertisement.get();
		}else {
			throw new AdvertiseNotFoundException("No such Advertisement");
		}
		return advertise;
	}

	@Override
	public List<Advertisement> searchAdvertise(String advertiseTitle){
		 List<Advertisement> advertise=advertisementRepo.findByAdvertiseTitle(advertiseTitle);
	        if(advertise==null) {
	            throw new AdvertiseNotFoundException("No such advertise");
	        }
	        return advertise;
	}
	

	@Override
	public Message sendMessage(MessageDTO messageDTO) {
		return messageRepo.save(converter.convertToMessageEntity(messageDTO));
	}



}
