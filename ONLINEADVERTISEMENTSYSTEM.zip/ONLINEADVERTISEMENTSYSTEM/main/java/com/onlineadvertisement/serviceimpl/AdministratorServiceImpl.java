package com.onlineadvertisement.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlineadvertisement.dto.AdminDTO;
import com.onlineadvertisement.dto.AdvertisementDTO;
import com.onlineadvertisement.dto.CategoryDTO;
import com.onlineadvertisement.entity.Admin;
import com.onlineadvertisement.entity.Advertisement;
import com.onlineadvertisement.entity.Category;
import com.onlineadvertisement.entity.Customer;
import com.onlineadvertisement.entity.User;
import com.onlineadvertisement.exception.AdvertiseNotFoundException;
import com.onlineadvertisement.exception.CustomerAlreadyExistException;
import com.onlineadvertisement.exception.CustomerNotFoundException;
import com.onlineadvertisement.repository.AdminRepository;
import com.onlineadvertisement.repository.AdvertisementRepository;
import com.onlineadvertisement.repository.CategoryRepository;
import com.onlineadvertisement.repository.CustomerRepository;
import com.onlineadvertisement.repository.UserRepository;
import com.onlineadvertisement.service.AdministratorService;
import com.onlineadvertisement.utils.Converter;

@Service
public class AdministratorServiceImpl implements AdministratorService {

	private static final Integer usrId = null;
	private static final Integer advertisementId = null;
	
	@Autowired
	private CustomerRepository customerRepo;
	
	@Autowired
    private AdvertisementRepository advertisementRepo;
    
	@Autowired
    private AdminRepository adminRepo;
    
	@Autowired
    private CategoryRepository categoryRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private Converter converter;
    
	@Override
	public String registerAdmin(AdminDTO adminDTO) {
		String message=null;
		Admin admin=null;
		 if(this.userRepo.existsByUserName(adminDTO.getUserName())) {
		        throw new CustomerAlreadyExistException("User with given userName already exist");
		 }
		 admin=adminRepo.save(converter.convertToAdminEntity(adminDTO));
		 if(admin!=null) {
		 message="register Successfull";
		 }
		 return message;
	}

	@Override
	public User loginAdmin(String userName, String password) {
		System.out.println(userName+" "+password);
		User user=userRepo.findByUserNameAndPassword(userName, password);

		if(user==null) {
		throw new CustomerNotFoundException("No such Customer");
		}

		return user;
	}

	@Override
	public Category addCategory(CategoryDTO categoryDTO) {
		return categoryRepo.save(converter.convertToCategoryEntity(categoryDTO));
	}

	@Override
	public List<Customer> viewAllCustomer() {
		return customerRepo.findAll();
	}

	@Override
	public Customer viewCustomer(int usrId) {
		Customer customer=null;
		Optional<Customer>customers=customerRepo.findById(usrId);
		if(customers.isPresent()){
		customer=customers.get();
		}
		else{
		throw new CustomerNotFoundException("No such Customer");
		}
		return customer;
	}

	@Override
	public Advertisement viewAdvertisement(int AdvertisementId) {
		Advertisement advertise=null;
		Optional<Advertisement>advertisement=advertisementRepo.findById(advertisementId);
		if(advertisement.isPresent()){
		advertise=advertisement.get();
		}
		else{
		throw new AdvertiseNotFoundException("No such Advertise");
		}
		return advertise;
	}

	@Override
	public Customer deleteCustomer(int usrId)  {
		Optional<Customer> customers = customerRepo.findById(usrId);
		Customer customer = null;
		if(customers.isPresent()) {
			customerRepo.deleteById(usrId);
			customer = customers.get();
		}else {
			throw new CustomerNotFoundException("No such Customer");
		}
		return customer;
	}

	@Override
	public String advertiseApproval(String result,AdvertisementDTO advertiseDTO) {
		if(result.equalsIgnoreCase("APPROVE")==true) {
		 advertisementRepo.save(converter.convertToAdvertisementEntity(advertiseDTO));
		}
		return result;
	}

	@Override
	public Advertisement deleteAdvertise(int advertisementId){
		Optional<Advertisement> advertisement = advertisementRepo.findById(advertisementId);
		Advertisement advertise = null;
		if(advertisement.isPresent()) {
			advertisementRepo.deleteById(advertisementId);
			advertise = advertisement.get();
		}else {
			throw new AdvertiseNotFoundException("No such Advertisement");
		}
		return advertise;
	}

}
