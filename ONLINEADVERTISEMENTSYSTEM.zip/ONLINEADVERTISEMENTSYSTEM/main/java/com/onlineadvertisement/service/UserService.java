package com.onlineadvertisement.service;

import java.util.List;

import com.onlineadvertisement.dto.AdvertisementDTO;
import com.onlineadvertisement.dto.CustomerDTO;
import com.onlineadvertisement.dto.MessageDTO;
import com.onlineadvertisement.entity.Advertisement;
import com.onlineadvertisement.entity.Customer;
import com.onlineadvertisement.entity.Message;
import com.onlineadvertisement.entity.User;

public interface UserService {

	public String registerCustomer(CustomerDTO customerDTO);
	public User loginCustomer(String userName,String password);
	public Customer editUserProfile(CustomerDTO customerDTO);
	public Advertisement postNewAdvertise(AdvertisementDTO advertiseDTO);
	public Advertisement editAdvertise(AdvertisementDTO advertiseDTO);
    public List<Advertisement> readAllAdvertises();
    public Advertisement readtheSpecificAdvertiseById(int advertisementId);
    public Advertisement deleteAdvertise(int advertisementId);
    public List<Advertisement> searchAdvertise(String advertiseTitle);
    public Message sendMessage(MessageDTO messageDTO);

	
}
