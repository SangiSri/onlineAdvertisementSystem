package com.onlineadvertisement.service;

import java.util.List;

import com.onlineadvertisement.dto.AdminDTO;
import com.onlineadvertisement.dto.AdvertisementDTO;
import com.onlineadvertisement.dto.CategoryDTO;
import com.onlineadvertisement.entity.Admin;
import com.onlineadvertisement.entity.Advertisement;
import com.onlineadvertisement.entity.Category;
import com.onlineadvertisement.entity.Customer;
import com.onlineadvertisement.entity.User;



public interface AdministratorService {
	
	public String registerAdmin(AdminDTO adminDTO);
	public User loginAdmin(String userName,String password);
	public Category addCategory(CategoryDTO categoryDTO );
	public List<Customer> viewAllCustomer();
	public Customer viewCustomer(int usrId) ;
    public Advertisement viewAdvertisement(int advertisementId) ;
	public Customer deleteCustomer(int usrId);
	public String advertiseApproval(String result,AdvertisementDTO advertiseDTO);
	public Advertisement deleteAdvertise(int advertisementId);
	
}
