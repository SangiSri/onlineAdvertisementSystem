package com.onlineadvertisement.utils;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.onlineadvertisement.dto.AdminDTO;
import com.onlineadvertisement.dto.AdvertisementDTO;
import com.onlineadvertisement.dto.CategoryDTO;
import com.onlineadvertisement.dto.CustomerDTO;
import com.onlineadvertisement.dto.MessageDTO;
import com.onlineadvertisement.dto.UserDTO;
import com.onlineadvertisement.entity.Admin;
import com.onlineadvertisement.entity.Advertisement;
import com.onlineadvertisement.entity.Category;
import com.onlineadvertisement.entity.Customer;
import com.onlineadvertisement.entity.Message;
import com.onlineadvertisement.entity.User;

@Component
public class Converter {

	//customerDto to customerEntity
	public Customer convertToCustomerEntity(CustomerDTO customerDTO) {
		Customer customer=new Customer();
		List<AdvertisementDTO> advertiseDTO=customerDTO.getAdvertisements();
		List<Advertisement>advertisements=new ArrayList<>();
		for(AdvertisementDTO advertise:advertiseDTO) {
			advertisements.add(convertToAdvertisementEntity(advertise));
		}
		BeanUtils.copyProperties(customerDTO, customer);
		customer.setAdvertisements(advertisements);
		System.out.println(customer);
		return customer;
	}
	
	//customerEntity to customerDto
	public CustomerDTO convertToCustomerDTO(Customer customer) {
		CustomerDTO customerDTO=new CustomerDTO();
		BeanUtils.copyProperties(customer, customerDTO);
		return customerDTO;
	}
	
	//adminDto to adminEntity
	public Admin convertToAdminEntity(AdminDTO adminDTO) {
		Admin admin=new Admin();
		BeanUtils.copyProperties(adminDTO, admin);
		return admin;
	}
	
	//adminEntity  to adminDto  
	public AdminDTO convertToAdminDTO(Admin admin) {
		AdminDTO adminDTO=new AdminDTO();
		BeanUtils.copyProperties(admin, adminDTO);
		return adminDTO;
	}
	
	//advertisementDto  to advertismentEntity
	public Advertisement convertToAdvertisementEntity(AdvertisementDTO advertisementDTO) {
		Advertisement advertisement=new Advertisement();
		
		CategoryDTO categoryDTO=advertisementDTO.getCategoryDTO();
		Category category=new Category();
		category=convertToCategoryEntity(categoryDTO);
		
		CustomerDTO customerDTO=advertisementDTO.getCustomerDTO();
		Customer customer=new Customer();
		customer=convertToCustomerEntity(customerDTO);
		
		BeanUtils.copyProperties(advertisementDTO, advertisement);
		advertisement.setCategory(category);
		advertisement.setCustomer(customer);
		return advertisement;
	}
	
	//advertisementEntity to advertisementDto
	public AdvertisementDTO convertToAdvertisementDTO(Advertisement advertisement) {
		AdvertisementDTO advertisementDTO=new AdvertisementDTO();
		BeanUtils.copyProperties(advertisement, advertisementDTO);
		return advertisementDTO;
	}
	
	//categoryDto to categoryEntity
	public Category convertToCategoryEntity(CategoryDTO categoryDTO) {
		Category category=new Category();
		BeanUtils.copyProperties(categoryDTO,category);
		return category;
	}
	
	//categoryEntity to categoryDto
	public CategoryDTO convertToCategoryDTO(Category category) {
		CategoryDTO categoryDTO=new CategoryDTO();
		BeanUtils.copyProperties(category,categoryDTO);
		return categoryDTO;
	}
	
	//userDto to userEntity
	public User convertToUserEntity(UserDTO userDTO) {
		User user=new User();
		BeanUtils.copyProperties(userDTO,user);
		return user;
	}
	
	//userEntity to userDto
	public UserDTO convertToUserDTO(User user) {
		UserDTO userDTO=new UserDTO();
		BeanUtils.copyProperties(user,userDTO);
		return userDTO;
	}
	
	//messageDto to messageEntity
	public Message convertToMessageEntity(MessageDTO messageDTO) {
		Message message=new Message();
		BeanUtils.copyProperties(messageDTO,message);
		return message;
	}
	
	//messageEntity to messageDto
	public MessageDTO convertToMessageDTO(Message message) {
		MessageDTO messageDTO=new MessageDTO();
		BeanUtils.copyProperties(message,messageDTO);
		return messageDTO;
	}
}
