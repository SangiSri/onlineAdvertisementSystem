package com.onlineadvertisement.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.onlineadvertisement.dto.AdminDTO;
import com.onlineadvertisement.dto.AdvertisementDTO;
import com.onlineadvertisement.dto.CategoryDTO;
import com.onlineadvertisement.entity.Admin;
import com.onlineadvertisement.entity.Advertisement;
import com.onlineadvertisement.entity.Category;
import com.onlineadvertisement.entity.Customer;
import com.onlineadvertisement.entity.User;
import com.onlineadvertisement.service.AdministratorService;

@RestController
public class AdministrationController {
	@Autowired
	private AdministratorService administratorService;

	@PostMapping(value = "/registerAdmin")
	public String registerAdmin(@RequestBody @Valid AdminDTO adminDTO) {
		return administratorService.registerAdmin(adminDTO);
	}

	@PostMapping(value = "/loginAdmin")
	public User loginAdmin(@RequestBody @Valid Admin admin) {
		String userName = admin.getUserName();
		String password = admin.getPassword();
		return administratorService.loginAdmin(userName, password);
	}

	@PostMapping(value = "/addcategory")
	public Category addCategory(@RequestBody @Valid CategoryDTO categoryDTO) {
		return administratorService.addCategory(categoryDTO);
	}

	@GetMapping(value = "/customer")
	public List<Customer> getCustomers() {
		return administratorService.viewAllCustomer();

	}

	@GetMapping(value = "/viewCustomer/{id}")
	public Customer viewCustomer(@PathVariable("id")  int usrId){
		return administratorService.viewCustomer(usrId);
	}

	@GetMapping(value = "/viewAdvertise/{id}")
	public Advertisement viewAdvertisement(@PathVariable("id")  int advertisementId)  {
		return administratorService.viewAdvertisement(advertisementId);
	}

	@DeleteMapping(value = "/deleteCustomer/{id}")
	public Customer deleteCustomer(@PathVariable("id")  int usrId) {
		return administratorService.deleteCustomer(usrId);
	}

	@RequestMapping(value = "/permission")
	public String advertiseApproval(@RequestBody @Valid String status,AdvertisementDTO advertiseDTO) {
		return administratorService.advertiseApproval(status,advertiseDTO);
	}

	@DeleteMapping(value = "/deleteAvertisement/{advertiseId}")
	public Advertisement deleteAdvertise(@PathVariable("advertiseId") int advertisementId) {
		return administratorService.deleteAdvertise(advertisementId);
	}
}
