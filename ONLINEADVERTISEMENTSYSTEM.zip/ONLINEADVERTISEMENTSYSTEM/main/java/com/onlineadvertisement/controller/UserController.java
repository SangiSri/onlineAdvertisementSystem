package com.onlineadvertisement.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.onlineadvertisement.dto.AdvertisementDTO;
import com.onlineadvertisement.dto.CustomerDTO;
import com.onlineadvertisement.dto.MessageDTO;
import com.onlineadvertisement.entity.Advertisement;
import com.onlineadvertisement.entity.Customer;
import com.onlineadvertisement.entity.Message;
import com.onlineadvertisement.entity.User;
import com.onlineadvertisement.service.UserService;

@RestController
public class UserController {

	@Autowired
	private UserService userService;

	@PostMapping(value = "/registerCustomer")
	public String registerCustomer(@RequestBody @Valid CustomerDTO customerDTO) {
		System.out.println(customerDTO.getAdvertisements());
		return userService.registerCustomer(customerDTO);
	}

	@PostMapping(value = "/loginCustomer")
	public User loginCustomer(@RequestBody @Valid CustomerDTO customerDTO) {
		String userName = customerDTO.getUserName();
		String password = customerDTO.getPassword();
		return userService.loginCustomer(userName, password);
	}

	@RequestMapping(value = "/editusr")
	public Customer editUserProfile(@RequestBody @Valid CustomerDTO customerDTO) {
		return userService.editUserProfile( customerDTO);
	}

	@PostMapping(value = "/postAd")
	public Advertisement postNewAdvertise(@RequestBody @Valid AdvertisementDTO advertiseDTO) {
		return userService.postNewAdvertise(advertiseDTO);
	}

	@RequestMapping(value = "/editAd")
	public Advertisement editAdvertise(@RequestBody @Valid AdvertisementDTO advertiseDTO) {
		return userService.editAdvertise( advertiseDTO);
	}

	@GetMapping(value = "/getAllAd")
	public List<Advertisement> getAllAdvertise() {
		return userService.readAllAdvertises();
	}

	@GetMapping(value = "/getAdvertise/{advertisementId}")
	public Advertisement readtheSpecificAdvertise(@PathVariable("advertisementId") int advertisementId) {
		return userService.readtheSpecificAdvertiseById(advertisementId);
	}

	@DeleteMapping(value = "/deleteAdvertise/{advertisementId}")
	public Advertisement deleteAdvertise(@PathVariable("advertisementId") int advertisementId) {
		return userService.deleteAdvertise(advertisementId);
	}

	@GetMapping(value = "/getAdvertise")
	public List<Advertisement> searchAdvertise(@RequestBody @Valid AdvertisementDTO advertiseDTO) {
		String title = advertiseDTO.getAdvertiseTitle();
		return userService.searchAdvertise(title);
	}

	@PostMapping(value = "/postmessage")
	public Message sendMessage(@RequestBody @Valid MessageDTO messageDTO) {
		return userService.sendMessage(messageDTO);
	}
}
